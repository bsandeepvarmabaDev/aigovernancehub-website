// AI Governance Hub API — verify-payment v24.0
import crypto from "crypto";
import {
  createRecoveryToken,
  createSuccessToken,
  getKeySecret,
  isNonEmptyString,
  safeCompare,
  validateSuccessToken,
  validateSessionToken,
} from "./lib/tokens.js";
import { generateHtmlReport, generateTextReport } from "./lib/report-engine.js";
import { generateAllExecutiveFormatsV24 } from "./lib/report-export-v24.js";
import { applyIndustryModel, normalizeIndustry } from "./lib/industry-models.js";
import { buildIntelligenceSnapshot } from "./lib/intelligence-snapshot.js";
import { hashEmailForAnalytics } from "./lib/platform-analytics.js";
import { getPlanById } from "./lib/assessment-config.js";
import {
  assertStorageConfigured,
  getReportExpiresAt,
  indexReportForEmail,
  indexPaymentOrder,
  indexSessionOrder,
  loadReportRecord,
  loadSessionRecord,
  maskOrderId,
  maskPaymentId,
  saveReportContent,
  saveReportRecord,
} from "./lib/storage.js";
import { enforceRateLimit, getClientIp, hashIp } from "./lib/rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./lib/audit.js";
import { sendPaymentEmails, isEmailConfigured } from "./lib/email.js";
import { trackEvent } from "./lib/analytics.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

async function buildVerifiedResponse(report, keySecret) {
  const confirmationToken = createSuccessToken(report.orderId, report.paymentId, keySecret);
  const recoveryToken = createRecoveryToken(
    report.orderId,
    report.paymentId,
    report.buyerEmail,
    keySecret
  );

  return {
    success: true,
    valid: true,
    confirmationToken,
    recoveryToken,
    orderId: report.orderId,
    paymentId: report.paymentId,
    message: "Payment verified. Your full report is ready to download.",
    downloadReady: true,
    availableFormats: report.availableFormats || ["html", "text"],
    emailStatus: report.emailSent ? "sent" : report.emailError ? "failed" : "pending",
    emailConfigured: isEmailConfigured(),
  };
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Payment verification is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Payment verification is not configured.");
  }

  const body = req.body || {};
  const token =
    typeof body.confirmationToken === "string"
      ? body.confirmationToken
      : typeof body.successToken === "string"
        ? body.successToken
        : "";

  if (isNonEmptyString(token)) {
    const tokenData = validateSuccessToken(token, keySecret);
    if (!tokenData) {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    const report = await loadReportRecord(tokenData.orderId);
    if (!report || report.paymentId !== tokenData.paymentId || report.paymentStatus !== "verified") {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    return sendJson(res, 200, {
      valid: true,
      orderId: tokenData.orderId,
      paymentId: tokenData.paymentId,
      message: "Payment verified. Your full report is ready to download.",
      downloadReady: true,
      emailStatus: report.emailSent ? "sent" : report.emailError ? "failed" : "pending",
      emailConfigured: isEmailConfigured(),
    });
  }

  const rateLimited = await enforceRateLimit(req, "verify-payment", body.email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderId = body.razorpay_order_id;
  const paymentId = body.razorpay_payment_id;
  const signature = body.razorpay_signature;
  const name = body.name;
  const email = body.email;
  const company = typeof body.company === "string" ? body.company.trim() : "";
  const sessionId = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";

  if (!isNonEmptyString(orderId) || !isNonEmptyString(paymentId) || !isNonEmptyString(signature)) {
    return sendError(res, 400, "Invalid payment verification request.");
  }

  if (!isNonEmptyString(name) || !isNonEmptyString(email)) {
    return sendError(res, 400, "Missing required contact details.");
  }

  if (!sessionId || !sessionToken) {
    return sendError(res, 400, "Upload session is required for report delivery.");
  }

  const existingReport = await loadReportRecord(orderId);
  if (
    existingReport &&
    existingReport.paymentStatus === "verified" &&
    existingReport.paymentId === paymentId
  ) {
    return sendJson(res, 200, await buildVerifiedResponse(existingReport, keySecret));
  }

  const sessionTokenData = validateSessionToken(sessionToken, keySecret);
  if (!sessionTokenData || sessionTokenData.sessionId !== sessionId) {
    return sendError(res, 400, "Upload session is invalid or expired.");
  }

  const session = await loadSessionRecord(sessionId);
  if (!session || session.contentHash !== sessionTokenData.contentHash) {
    return sendError(res, 400, "Upload session not found. Upload your file again.");
  }

  if (session.pendingCheckout && session.pendingCheckout.orderId !== orderId) {
    return sendError(res, 400, "Payment verification failed.");
  }

  const expectedSignature = crypto
    .createHmac("sha256", keySecret)
    .update(`${orderId}|${paymentId}`)
    .digest("hex");

  if (!safeCompare(expectedSignature, signature)) {
    return sendError(res, 400, "Payment verification failed.");
  }

  const createdAt = new Date().toISOString();
  const planTier = session.planTier || session.pendingCheckout?.planId || "starter";
  const plan = getPlanById(planTier);
  const reportMeta = {
    buyerName: name,
    buyerEmail: email,
    company,
    orderId,
    paymentId,
    orderRef: maskOrderId(orderId),
    paymentRef: maskPaymentId(paymentId),
    paidAt: createdAt,
    planTier,
    planLabel: plan.label,
  };

  const executiveRaw = session.executiveAssessment;
  const industry = normalizeIndustry(session.industry || body.industry);
  const executive = executiveRaw ? applyIndustryModel(executiveRaw, industry) : null;
  let availableFormats = ["html", "text"];

  if (executive) {
    const formats = await generateAllExecutiveFormatsV24(executive, reportMeta);
    await saveReportContent(orderId, formats.html, formats.text, {
      pdf: formats.pdf,
      docx: formats.docx,
      pptx: formats.pptx,
    });
    availableFormats = ["html", "text", "pdf", "docx", "pptx"];
  } else {
    const html = generateHtmlReport(session.analysis, reportMeta);
    const text = generateTextReport(session.analysis, reportMeta);
    await saveReportContent(orderId, html, text);
  }

  const intelligenceSnapshot = executive
    ? buildIntelligenceSnapshot(executive, {
        orderId,
        orderRef: maskOrderId(orderId),
        paidAt: createdAt,
        industry,
        source: session.source,
        company,
        planTier,
        planLabel: plan.label,
      })
    : null;

  const reportRecord = {
    orderId,
    paymentId,
    sessionId,
    buyerName: name,
    buyerEmail: email,
    company: company || null,
    industry,
    planTier,
    planLabel: plan.label,
    reportVersion: executive ? "24.0" : "21.0",
    governanceScore: executive?.executiveSummary?.governanceScore ?? session.preview?.governanceScore ?? null,
    aiReadiness: executive?.executiveSummary?.aiReadiness ?? session.preview?.aiReadiness ?? null,
    availableFormats,
    intelligenceSnapshot,
    paymentStatus: "verified",
    createdAt,
    expiresAt: getReportExpiresAt(new Date(createdAt)),
    downloadCount: 0,
    lastDownloadAt: null,
    lastDownloadIpHash: null,
    preview: session.preview,
    emailSent: false,
    emailError: null,
  };

  await saveReportRecord(reportRecord);
  await indexReportForEmail(email, orderId, keySecret);
  await indexPaymentOrder(paymentId, orderId);
  await indexSessionOrder(sessionId, orderId);

  await logAudit(orderId, AUDIT_EVENTS.PAYMENT_VERIFIED, {
    sessionId,
    email,
    ipHash: hashIp(getClientIp(req), keySecret),
  });
  await logAudit(orderId, AUDIT_EVENTS.REPORT_GENERATED, { sessionId, email });

  const recoveryToken = createRecoveryToken(orderId, paymentId, email, keySecret);
  const siteUrl = getSiteUrl();
  const emailResult = await sendPaymentEmails({
    buyerName: name,
    buyerEmail: email,
    company,
    orderRef: maskOrderId(orderId),
    paymentRef: maskPaymentId(paymentId),
    paidAt: createdAt,
    downloadUrl: `${siteUrl}/recover-report.html`,
    recoverUrl: `${siteUrl}/recover-report.html`,
    dashboardUrl: `${siteUrl}/dashboard.html`,
    governanceScore: reportRecord.governanceScore,
    topRecommendation: executive?.recommendations?.[0]?.title || executive?.executiveSummary?.overallRecommendation || null,
    planLabel: plan.label,
    availableFormats,
  });

  reportRecord.emailSent = emailResult.sent === true;
  reportRecord.emailError = emailResult.sent ? null : emailResult.reason || "Email not sent.";
  await saveReportRecord(reportRecord);

  if (emailResult.sent) {
    await logAudit(orderId, AUDIT_EVENTS.REPORT_EMAILED, { email });
  } else {
    await logAudit(orderId, AUDIT_EVENTS.REPORT_EMAIL_FAILED, {
      email,
      reason: reportRecord.emailError,
    });
  }

  await trackEvent("payment_verified", req, {
    correlationId,
    orderId,
    planTier,
    emailHash: hashEmailForAnalytics(email, keySecret),
  });

  return sendJson(res, 200, {
    ...(await buildVerifiedResponse(reportRecord, keySecret)),
    emailStatus: reportRecord.emailSent ? "sent" : "failed",
  });
}
