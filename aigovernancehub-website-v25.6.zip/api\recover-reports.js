// AI Governance Hub API — recover-reports v18.0
import {
  createRecoveryToken,
  getKeySecret,
  isNonEmptyString,
} from "./lib/tokens.js";
import {
  assertStorageConfigured,
  listReportIdsForEmail,
  loadReportRecord,
  maskOrderId,
  normalizeEmail,
} from "./lib/storage.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./lib/audit.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { trackEvent } from "./lib/analytics.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Recovery service is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Recovery service is not configured.");
  }

  const body = req.body || {};
  const email = normalizeEmail(body.email);

  if (!isNonEmptyString(email) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return sendError(res, 400, "A valid email address is required.");
  }

  const rateLimited = await enforceRateLimit(req, "recover-reports", email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderIds = await listReportIdsForEmail(email, keySecret);
  const reports = [];

  for (const orderId of orderIds) {
    const report = await loadReportRecord(orderId);
    if (!report || report.paymentStatus !== "verified" || report.buyerEmail !== email) {
      continue;
    }

    const expiresAt = report.expiresAt ? Date.parse(report.expiresAt) : null;
    if (expiresAt && Date.now() > expiresAt) {
      continue;
    }

    const recoveryToken = createRecoveryToken(orderId, report.paymentId, email, keySecret);

    reports.push({
      orderRef: maskOrderId(orderId),
      purchasedAt: report.createdAt,
      downloadCount: Number(report.downloadCount || 0),
      expiresAt: report.expiresAt,
      governanceScore: report.governanceScore ?? null,
      planLabel: report.planLabel || "Executive Assessment",
      availableFormats: report.availableFormats || ["html", "text"],
      recoveryToken,
    });

    await logAudit(orderId, AUDIT_EVENTS.REPORT_RECOVERED, { email });
  }

  await trackEvent("recovery_used", req, { correlationId, reportCount: reports.length });

  return sendJson(res, 200, {
    email,
    reports,
    message:
      reports.length > 0
        ? "Purchased reports found."
        : "If reports exist for this email, they will appear here.",
  });
}
