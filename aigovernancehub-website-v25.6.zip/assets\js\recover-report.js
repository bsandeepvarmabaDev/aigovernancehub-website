/**
 * AI Governance Hub — Recover purchased reports v23.0
 */
(function () {
  "use strict";

  var RECOVER_URL = "/api/recover-reports";
  var DOWNLOAD_URL = "/api/download-report";

  function ux() {
    return window.AGHUX || null;
  }

  function setStatus(message, isError) {
    var status = document.getElementById("recover-status");
    if (!status) return;
    var api = ux();
    if (api) {
      api.setStatusEl(status, message, isError ? "error" : message ? "info" : null);
      return;
    }
    status.textContent = message || "";
    status.classList.toggle("starter-upload-error", Boolean(isError));
  }

  function formatDate(value) {
    if (!value) return "—";
    try {
      return new Date(value).toLocaleString();
    } catch {
      return value;
    }
  }

  function downloadReport(recoveryToken, email, format) {
    setStatus("Preparing your secure download…", false);
    return fetch(DOWNLOAD_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recoveryToken: recoveryToken,
        email: email,
        format: format,
      }),
    }).then(function (response) {
      if (!response.ok) {
        return response.json().then(function (data) {
          throw new Error((data && data.error) || "Download could not be completed.");
        });
      }
      var disposition = response.headers.get("Content-Disposition") || "";
      var filenameMatch = disposition.match(/filename=\"([^\"]+)\"/);
      var filename = filenameMatch ? filenameMatch[1] : "ai-governance-executive-report.html";
      return response.blob().then(function (blob) {
        return { blob: blob, filename: filename };
      });
    });
  }

  function renderReports(email, reports) {
    var container = document.getElementById("recover-list");
    var panel = document.getElementById("recover-results");
    if (!container || !panel) return;

    container.innerHTML = "";

    if (!reports.length) {
      panel.hidden = false;
      var api = ux();
      if (api) {
        api.showEmptyState(container, {
          icon: "🔍",
          title: "No reports found for this email",
          body: "We could not find active assessments for that address. Use the email from checkout, or start a new guided assessment if you have not purchased yet.",
          ctaLabel: "Start Guided Assessment",
          ctaHref: "pricing.html#assessment-wizard",
          secondaryLabel: "Contact Support",
          secondaryHref: "mailto:support@aigovernancehub.ai",
        });
      }
      setStatus(
        "No active reports were found. Confirm you used the same email as checkout, or contact support if you recently paid.",
        true
      );
      return;
    }

    var labels = { html: "HTML", pdf: "PDF", docx: "Word", pptx: "PowerPoint", text: "Text" };

    reports.forEach(function (report) {
      var card = document.createElement("article");
      card.className = "recover-report-card";
      var scoreLine =
        report.governanceScore != null
          ? "<p><strong>Governance Score:</strong> " + report.governanceScore + "/100</p>"
          : "";
      card.innerHTML =
        "<h3>" + (report.planLabel || "Executive Assessment") + "</h3>" +
        scoreLine +
        "<p><strong>Reference:</strong> " + report.orderRef + "</p>" +
        "<p><strong>Purchased:</strong> " + formatDate(report.purchasedAt) + "</p>" +
        "<p><strong>Downloads:</strong> " + String(report.downloadCount || 0) + "</p>" +
        '<div class="report-action-row report-format-row"></div>';

      var actions = card.querySelector(".report-action-row");
      var formats = report.availableFormats || ["html", "text"];
      formats.forEach(function (fmt) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = fmt === "html" ? "btn btn-primary" : "btn btn-secondary";
        btn.textContent = "Download " + (labels[fmt] || fmt.toUpperCase());
        btn.addEventListener("click", function () {
          downloadReport(report.recoveryToken, email, fmt)
            .then(function (payload) {
              var url = URL.createObjectURL(payload.blob);
              var link = document.createElement("a");
              link.href = url;
              link.download = payload.filename;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              setStatus("Download started. You can also sign in to My Reports for future access.", false);
            })
            .catch(function (error) {
              setStatus(error.message, true);
            });
        });
        actions.appendChild(btn);
      });
      container.appendChild(card);
    });

    panel.hidden = false;
    setStatus(
      reports.length +
        " report(s) found. Downloads use secure, time-limited links — sign in to My Reports for ongoing access.",
      false
    );
  }

  function bindForm() {
    var form = document.getElementById("recover-form");
    if (!form) return;

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var emailInput = document.getElementById("recover-email");
      var email = emailInput ? emailInput.value.trim() : "";
      if (!email) {
        setStatus("Enter the email address you used at checkout.", true);
        return;
      }

      var submitBtn = document.getElementById("recover-submit");
      var api = ux();
      if (api) api.setBusy(submitBtn, true, "Searching…");

      setStatus("Searching for your purchased assessments…", false);
      document.getElementById("recover-results").hidden = true;

      fetch(RECOVER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email }),
      })
        .then(function (response) {
          return response.json().then(function (data) {
            return { ok: response.ok, data: data };
          });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error((result.data && result.data.error) || "We could not look up reports for that email.");
          }
          renderReports(result.data.email, result.data.reports || []);
        })
        .catch(function (error) {
          setStatus(error.message, true);
        })
        .finally(function () {
          if (api) api.setBusy(submitBtn, false);
        });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindForm);
  } else {
    bindForm();
  }
})();
