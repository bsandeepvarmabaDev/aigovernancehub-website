/**
 * Post-checkout success page — payment verify and downloads (v25.14, CSP-safe external script).
 */
(function () {
  "use strict";

  var params = new URLSearchParams(window.location.search);
  var token = params.get("confirmation");
  var unverified = document.getElementById("success-unverified");
  var verified = document.getElementById("success-verified");
  var downloadActions = document.getElementById("download-actions");
  var downloadStatus = document.getElementById("download-status");
  var emailStatusLine = document.getElementById("email-status-line");

  var FORMATS = [
    { id: "html", label: "Download HTML", primary: true },
    { id: "pdf", label: "Download PDF", primary: false },
    { id: "docx", label: "Download Word", primary: false },
    { id: "pptx", label: "Download PowerPoint", primary: false },
    { id: "text", label: "Download Plain Text", primary: false },
  ];

  function setDownloadStatus(msg, isError) {
    var api = window.AGHUX;
    if (api) {
      api.setStatusEl(downloadStatus, msg, isError ? "error" : msg ? "success" : "loading");
      return;
    }
    downloadStatus.textContent = msg || "";
  }

  function focusVerifiedHeading() {
    var heading = verified && verified.querySelector("h1");
    if (heading) {
      heading.setAttribute("tabindex", "-1");
      heading.focus();
    }
  }

  if (!token) return;

  setDownloadStatus("Verifying payment and preparing your assessment…", false);

  fetch("/api/verify-payment", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ confirmationToken: token }),
  })
    .then(function (response) {
      return response.json().then(function (data) {
        return { ok: response.ok, data: data };
      });
    })
    .then(function (result) {
      if (!(result.ok && result.data && result.data.valid === true && result.data.downloadReady === true)) {
        setDownloadStatus("", false);
        return;
      }

      unverified.hidden = true;
      verified.hidden = false;
      document.title = "Assessment Ready | AI Governance Hub";
      setDownloadStatus("", false);
      focusVerifiedHeading();
      if (window.AGHStarterExperience && typeof window.AGHStarterExperience.initSuccessCelebration === "function") {
        window.AGHStarterExperience.initSuccessCelebration();
      }

      if (result.data.emailStatus === "sent") {
        emailStatusLine.textContent =
          "A confirmation email with download instructions has been sent to your checkout address.";
      } else if (result.data.emailStatus === "failed") {
        emailStatusLine.textContent =
          "Email delivery is temporarily unavailable. Download below or sign in to My Reports anytime.";
      } else {
        emailStatusLine.textContent =
          "Download your assessment below. Sign in to My Reports for ongoing access.";
      }

      var available = result.data.availableFormats || ["html", "text"];

      FORMATS.forEach(function (fmt) {
        if (available.indexOf(fmt.id) === -1) return;
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = fmt.primary ? "btn btn-primary" : "btn btn-secondary";
        btn.textContent = fmt.label;
        btn.addEventListener("click", function () {
          setDownloadStatus("Preparing your " + fmt.label.replace("Download ", "") + "…", false);
          fetch("/api/download-report", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ confirmationToken: token, format: fmt.id }),
          })
            .then(function (response) {
              if (!response.ok) {
                return response.json().then(function (data) {
                  var api = window.AGHUX;
                  var msg = (data && data.error) || "Download could not be completed.";
                  if (api) {
                    var norm = api.normalizeError(msg);
                    throw new Error(norm.title + " — " + norm.fix);
                  }
                  throw new Error(msg);
                });
              }
              var disposition = response.headers.get("Content-Disposition") || "";
              var filenameMatch = disposition.match(/filename=\"([^\"]+)\"/);
              var filename = filenameMatch ? filenameMatch[1] : "ai-governance-executive-report." + fmt.id;
              return response.blob().then(function (blob) {
                return { blob: blob, filename: filename };
              });
            })
            .then(function (payload) {
              var url = URL.createObjectURL(payload.blob);
              var link = document.createElement("a");
              link.href = url;
              link.download = payload.filename;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              setDownloadStatus("Download started. Check your downloads folder.", false);
            })
            .catch(function (error) {
              setDownloadStatus(error.message, true);
            });
        });
        downloadActions.appendChild(btn);
      });
    })
    .catch(function () {
      setDownloadStatus("", false);
    });
})();
