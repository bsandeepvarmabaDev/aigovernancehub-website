// AI Governance Hub API — customer dashboard v22.0
import { createRecoveryToken, getKeySecret } from "./lib/tokens.js";
import {
  listReportIdsForEmail,
  loadReportRecord,
  maskOrderId,
} from "./lib/storage.js";
import { requireAuth } from "./lib/auth.js";
import { trackEvent } from "./lib/analytics.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return sendError(res, 405, "Method not allowed.");
  }

  const session = await requireAuth(req);
  if (!session) {
    return sendError(res, 401, "Sign in required.");
  }

  const keySecret = getKeySecret();
  const orderIds = await listReportIdsForEmail(session.email, keySecret);
  const reports = [];

  for (const orderId of orderIds) {
    const report = await loadReportRecord(orderId);
    if (!report || report.buyerEmail !== session.email) continue;
    const recoveryToken = createRecoveryToken(orderId, report.paymentId, session.email, keySecret);
    reports.push({
      orderRef: maskOrderId(orderId),
      purchasedAt: report.createdAt,
      paymentStatus: report.paymentStatus,
      planTier: report.planTier || "starter",
      planLabel: report.planLabel || "Starter",
      reportVersion: report.reportVersion || "22.0",
      governanceScore: report.governanceScore ?? report.preview?.governanceScore ?? null,
      availableFormats: report.availableFormats || ["html", "text"],
      downloadCount: Number(report.downloadCount || 0),
      lastDownloadAt: report.lastDownloadAt,
      emailSent: Boolean(report.emailSent),
      expiresAt: report.expiresAt,
      downloadDisabled: Boolean(report.downloadDisabled),
      recoveryToken,
      invoiceAvailable: report.paymentStatus === "verified",
    });
  }

  await trackEvent("dashboard_viewed", req, { correlationId });

  return sendJson(res, 200, {
    email: session.email,
    reports,
  });
}
