/**
 * AI Governance Hub — admin portal v18.0
 */
(function () {
  "use strict";

  var adminKey = sessionStorage.getItem("agh_admin_key") || "";

  function headers() {
    return {
      "Content-Type": "application/json",
      Authorization: "Bearer " + adminKey,
    };
  }

  function setStatus(msg, isError) {
    var el = document.getElementById("admin-status");
    if (!el) return;
    el.textContent = msg || "";
    el.classList.toggle("starter-upload-error", Boolean(isError));
  }

  function bindKeyForm() {
    var form = document.getElementById("admin-key-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      adminKey = document.getElementById("admin-key").value.trim();
      sessionStorage.setItem("agh_admin_key", adminKey);
      document.getElementById("admin-panel").hidden = false;
      form.hidden = true;
      loadAnalytics();
    });
    if (adminKey) {
      document.getElementById("admin-panel").hidden = false;
      form.hidden = true;
      loadAnalytics();
    }
  }

  function loadAnalytics() {
    fetch("/api/admin-analytics", { headers: { Authorization: "Bearer " + adminKey } })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        var el = document.getElementById("admin-analytics");
        if (el && data.summary) {
          el.textContent = JSON.stringify(data.summary, null, 2);
        }
      })
      .catch(function () {});
  }

  function bindSearch() {
    var form = document.getElementById("admin-search-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var query = document.getElementById("admin-query").value.trim();
      setStatus("Searching…", false);
      fetch("/api/admin-search", {
        method: "POST",
        headers: headers(),
        body: JSON.stringify({ query: query }),
      })
        .then(function (r) {
          return r.json().then(function (d) {
            return { ok: r.ok, data: d };
          });
        })
        .then(function (result) {
          if (!result.ok) throw new Error((result.data && result.data.error) || "Search failed.");
          renderResults(result.data.results || []);
        })
        .catch(function (err) {
          setStatus(err.message, true);
        });
    });
  }

  function adminAction(orderId, action) {
    return fetch("/api/admin-actions", {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ orderId: orderId, action: action }),
    });
  }

  function renderResults(results) {
    var list = document.getElementById("admin-results");
    if (!list) return;
    list.innerHTML = "";
    if (!results.length) {
      setStatus("No results found.", true);
      return;
    }
    setStatus("", false);
    results.forEach(function (item) {
      if (item.type === "session") return;
      var card = document.createElement("article");
      card.className = "recover-report-card";
      card.innerHTML =
        "<h3>" +
        (item.orderRef || "Report") +
        "</h3>" +
        "<p>Email: " +
        (item.buyerEmail || "—") +
        "</p>" +
        "<p>Payment: " +
        (item.paymentStatus || "—") +
        "</p>" +
        "<p>Downloads: " +
        (item.downloadCount || 0) +
        "</p>" +
        "<p>Email sent: " +
        (item.emailSent ? "Yes" : "No") +
        "</p>" +
        '<div class="report-action-row"></div>';
      var actions = card.querySelector(".report-action-row");
      ["resend_email", "disable_download", "delete_expired"].forEach(function (action) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "btn btn-secondary";
        btn.textContent = action.replace(/_/g, " ");
        btn.addEventListener("click", function () {
          adminAction(item.orderId, action).then(function () {
            setStatus("Action completed: " + action, false);
          });
        });
        actions.appendChild(btn);
      });
      list.appendChild(card);
    });
  }

  bindKeyForm();
  bindSearch();
})();
