// AI Governance Hub API — admin actions v18.0
import {
  loadReportRecord,
  saveReportRecord,
  maskOrderId,
  maskPaymentId,
} from "./lib/storage.js";
import { sendReportResendEmail } from "./lib/email.js";
import { isAdminAuthorized } from "./lib/correlation.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { logAudit, AUDIT_EVENTS } from "./lib/audit.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation, logEvent } from "./lib/correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  if (!isAdminAuthorized(req)) {
    return sendError(res, 403, "Admin access denied.");
  }

  const rateLimited = await enforceRateLimit(req, "admin-actions");
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const body = req.body || {};
  const action = typeof body.action === "string" ? body.action : "";
  const orderId = typeof body.orderId === "string" ? body.orderId.trim() : "";

  if (!orderId) {
    return sendError(res, 400, "Order ID is required.");
  }

  const report = await loadReportRecord(orderId);
  if (!report) {
    return sendError(res, 404, "Report not found.");
  }

  if (action === "resend_email") {
    const siteUrl = getSiteUrl();
    const result = await sendReportResendEmail({
      buyerName: report.buyerName,
      buyerEmail: report.buyerEmail,
      company: report.company,
      orderRef: maskOrderId(orderId),
      paymentRef: maskPaymentId(report.paymentId),
      paidAt: report.createdAt,
      downloadUrl: `${siteUrl}/dashboard.html`,
      recoverUrl: `${siteUrl}/recover-report.html`,
    });
    report.emailSent = result.sent === true;
    report.emailError = result.sent ? null : result.reason;
    await saveReportRecord(report);
    await logAudit(orderId, AUDIT_EVENTS.REPORT_EMAILED, { admin: true, correlationId });
    return sendJson(res, 200, { success: true, emailSent: result.sent });
  }

  if (action === "disable_download") {
    report.downloadDisabled = true;
    await saveReportRecord(report);
    logEvent("warn", "admin_disable_download", { correlationId, orderId });
    return sendJson(res, 200, { success: true, downloadDisabled: true });
  }

  if (action === "enable_download") {
    report.downloadDisabled = false;
    await saveReportRecord(report);
    return sendJson(res, 200, { success: true, downloadDisabled: false });
  }

  if (action === "delete_expired") {
    report.paymentStatus = "deleted";
    report.downloadDisabled = true;
    await saveReportRecord(report);
    logEvent("warn", "admin_delete_report", { correlationId, orderId });
    return sendJson(res, 200, { success: true, status: "deleted" });
  }

  return sendError(res, 400, "Unsupported admin action.");
}
