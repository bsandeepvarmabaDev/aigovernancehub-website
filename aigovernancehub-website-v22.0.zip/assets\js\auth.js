/**
 * AI Governance Hub — login / magic link v18.0
 */
(function () {
  "use strict";

  function setStatus(msg, isError) {
    var el = document.getElementById("login-status");
    if (!el) return;
    el.textContent = msg || "";
    el.classList.toggle("starter-upload-error", Boolean(isError));
  }

  function verifyTokenFromUrl() {
    var params = new URLSearchParams(window.location.search);
    var token = params.get("token");
    var redirect = params.get("redirect") || "/dashboard.html";
    if (!token) return;

    setStatus("Verifying sign-in link…", false);
    fetch("/api/auth-verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ token: token }),
    })
      .then(function (r) {
        return r.json().then(function (d) {
          return { ok: r.ok, data: d };
        });
      })
      .then(function (result) {
        if (result.ok && result.data.authenticated) {
          window.location.href = redirect;
          return;
        }
        setStatus((result.data && result.data.error) || "Sign-in failed.", true);
      })
      .catch(function () {
        setStatus("Sign-in failed.", true);
      });
  }

  function bindForm() {
    var form = document.getElementById("login-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var email = document.getElementById("login-email").value.trim();
      setStatus("Sending sign-in link…", false);
      fetch("/api/auth-magic-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, redirect: "/dashboard.html" }),
      })
        .then(function (r) {
          return r.json().then(function (d) {
            return { ok: r.ok, data: d };
          });
        })
        .then(function (result) {
          if (!result.ok) throw new Error((result.data && result.data.error) || "Request failed.");
          setStatus(result.data.message || "Check your email for a sign-in link.", false);
        })
        .catch(function (err) {
          setStatus(err.message || "Request failed.", true);
        });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      bindForm();
      verifyTokenFromUrl();
    });
  } else {
    bindForm();
    verifyTokenFromUrl();
  }
})();
