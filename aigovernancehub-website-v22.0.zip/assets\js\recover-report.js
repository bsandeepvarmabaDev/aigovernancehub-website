/**
 * AI Governance Hub — Recover purchased reports (recover-report.html)
 * v17.1: server-side email lookup with signed recovery tokens.
 */
(function () {
  "use strict";

  const RECOVER_URL = "/api/recover-reports";
  const DOWNLOAD_URL = "/api/download-report";

  function setStatus(message, isError) {
    var status = document.getElementById("recover-status");
    if (!status) return;
    status.textContent = message || "";
    status.classList.toggle("starter-upload-error", Boolean(isError));
  }

  function formatDate(value) {
    if (!value) return "—";
    try {
      return new Date(value).toLocaleString();
    } catch {
      return value;
    }
  }

  function downloadReport(recoveryToken, email, format) {
    return fetch(DOWNLOAD_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recoveryToken: recoveryToken,
        email: email,
        format: format,
      }),
    }).then(function (response) {
      if (!response.ok) {
        return response.json().then(function (data) {
          throw new Error((data && data.error) || "Download failed.");
        });
      }
      var disposition = response.headers.get("Content-Disposition") || "";
      var filenameMatch = disposition.match(/filename=\"([^\"]+)\"/);
      var filename = filenameMatch ? filenameMatch[1] : "ai-governance-starter-report.html";
      return response.blob().then(function (blob) {
        return { blob: blob, filename: filename };
      });
    });
  }

  function renderReports(email, reports) {
    var container = document.getElementById("recover-list");
    var panel = document.getElementById("recover-results");
    if (!container || !panel) return;

    container.innerHTML = "";

    if (!reports.length) {
      setStatus("No active reports were found for this email.", true);
      panel.hidden = true;
      return;
    }

    reports.forEach(function (report) {
      var card = document.createElement("article");
      card.className = "recover-report-card";
      var scoreLine =
        report.governanceScore != null
          ? "<p><strong>Governance Score:</strong> " + report.governanceScore + "/100</p>"
          : "";
      card.innerHTML =
        "<h3>" + (report.planLabel || "Executive Assessment") + "</h3>" +
        scoreLine +
        "<p><strong>Reference:</strong> " +
        report.orderRef +
        "</p>" +
        "<p><strong>Purchased:</strong> " +
        formatDate(report.purchasedAt) +
        "</p>" +
        "<p><strong>Downloads:</strong> " +
        String(report.downloadCount || 0) +
        "</p>" +
        '<div class="report-action-row report-format-row"></div>';

      var actions = card.querySelector(".report-action-row");
      var formats = report.availableFormats || ["html", "text"];
      var labels = { html: "HTML", pdf: "PDF", docx: "Word", pptx: "PowerPoint", text: "Text" };
      formats.forEach(function (fmt) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = fmt === "html" ? "btn btn-primary" : "btn btn-secondary";
        btn.textContent = "Download " + (labels[fmt] || fmt.toUpperCase());
        btn.addEventListener("click", function () {
          setStatus("Preparing download…", false);
          downloadReport(report.recoveryToken, email, fmt)
            .then(function (payload) {
              var url = URL.createObjectURL(payload.blob);
              var link = document.createElement("a");
              link.href = url;
              link.download = payload.filename;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
              setStatus("Download started.", false);
            })
            .catch(function (error) {
              setStatus(error.message || "Download failed.", true);
            });
        });
        actions.appendChild(btn);
      });
      container.appendChild(card);
    });

    panel.hidden = false;
    setStatus("Reports loaded. Download requires a valid server-issued recovery token.", false);
  }

  function bindForm() {
    var form = document.getElementById("recover-form");
    if (!form) return;

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var emailInput = document.getElementById("recover-email");
      var email = emailInput ? emailInput.value.trim() : "";
      if (!email) {
        setStatus("Enter the email used at checkout.", true);
        return;
      }

      setStatus("Looking up purchased reports…", false);
      document.getElementById("recover-results").hidden = true;

      fetch(RECOVER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email }),
      })
        .then(function (response) {
          return response.json().then(function (data) {
            return { ok: response.ok, data: data };
          });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error((result.data && result.data.error) || "Recovery lookup failed.");
          }
          renderReports(result.data.email, result.data.reports || []);
        })
        .catch(function (error) {
          setStatus(error.message || "Recovery lookup failed.", true);
        });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bindForm);
  } else {
    bindForm();
  }
})();
