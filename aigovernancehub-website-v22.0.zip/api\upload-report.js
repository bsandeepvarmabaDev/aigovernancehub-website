// AI Governance Hub API — upload-report v22.0
import crypto from "crypto";
import {
  parseUploadContent,
  analyzeRecords,
  validateFileMeta,
  validateEncoding,
  validateUploadStructure,
  buildPreview,
  SUPPORTED_SOURCES,
} from "./lib/report-engine.js";
import { buildExecutiveAssessment } from "./lib/executive-intelligence.js";
import { getPlanById } from "./lib/assessment-config.js";
import { createSessionToken, getKeySecret, hashContent } from "./lib/tokens.js";
import {
  assertStorageConfigured,
  getSessionExpiresAt,
  saveSessionRecord,
  saveUploadedFile,
} from "./lib/storage.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { trackEvent } from "./lib/analytics.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Upload service is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Upload service is not configured.");
  }

  const rateLimited = await enforceRateLimit(req, "upload-report");
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const body = req.body || {};
  const filename = typeof body.filename === "string" ? body.filename.trim() : "";
  const contentBase64 = typeof body.contentBase64 === "string" ? body.contentBase64 : "";
  const source = typeof body.source === "string" ? body.source.trim().toLowerCase() : "csv";

  if (!SUPPORTED_SOURCES.includes(source)) {
    return sendError(res, 400, "Choose a supported project source before uploading.");
  }

  if (!contentBase64) {
    return sendError(res, 400, "No file content provided.");
  }

  let buffer;
  try {
    buffer = Buffer.from(contentBase64, "base64");
  } catch {
    return sendError(res, 400, "Invalid file encoding.");
  }

  const validationError = validateFileMeta(filename, buffer.length);
  if (validationError) {
    return sendError(res, 400, validationError);
  }

  const encodingError = validateEncoding(buffer);
  if (encodingError) {
    return sendError(res, 400, encodingError);
  }

  const rawText = buffer.toString("utf8");

  let parsed;
  try {
    parsed = parseUploadContent(filename, buffer);
  } catch (error) {
    return sendError(
      res,
      400,
      error instanceof Error ? error.message : "Unable to read uploaded file. Export as CSV and try again."
    );
  }

  const structure = validateUploadStructure(parsed, buffer.length, rawText, source);

  if (!structure.ready) {
    return sendJson(res, 400, {
      error: structure.issues[0] || "File validation failed. Check required columns and try again.",
      validation: structure,
    });
  }

  const analysis = analyzeRecords(parsed.records);
  const plan = getPlanById(structure.plan.tier);
  const executiveAssessment = buildExecutiveAssessment(parsed.records, analysis, {
    source,
    uploadDate: new Date().toISOString(),
    filename,
    planTier: structure.plan.tier,
    planLabel: plan.label,
  });
  const sessionId = crypto.randomUUID();
  const contentHash = hashContent(JSON.stringify({ analyzed: analysis.analyzed, v: executiveAssessment.version }));
  const sessionToken = createSessionToken(sessionId, contentHash, keySecret);
  const createdAt = new Date().toISOString();
  const uploadStorageKey = await saveUploadedFile(sessionId, filename, buffer);
  const preview = buildPreview(analysis, structure, executiveAssessment);

  await saveSessionRecord({
    sessionId,
    filename,
    source,
    contentHash,
    createdAt,
    expiresAt: getSessionExpiresAt(new Date(createdAt)),
    uploadStorageKey,
    preview,
    analysis,
    executiveAssessment,
    validation: structure,
    selfServeAllowed: structure.selfServe,
    planTier: structure.plan.tier,
    paymentStatus: "pending",
  });

  await trackEvent("upload_completed", req, {
    correlationId,
    sessionId,
    source,
    planTier: structure.plan.tier,
  });

  return sendJson(res, 200, {
    sessionId,
    sessionToken,
    preview,
    compatibility: structure.compatibility,
    plan: structure.plan,
    fieldReport: structure.fieldReport,
    source,
  });
}
