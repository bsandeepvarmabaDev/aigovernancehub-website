// AI Governance Hub API — create-order v21.0
import { getKeySecret, trimEnv, validateSessionToken } from "./lib/tokens.js";
import { assertStorageConfigured, loadSessionRecord, saveSessionRecord } from "./lib/storage.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./lib/audit.js";
import { buildOrderQuote, detectCurrency } from "./lib/pricing.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { trackEvent } from "./lib/analytics.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Payment service is temporarily unavailable.");
  }

  const rateLimited = await enforceRateLimit(req, "create-order");
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const keyId = trimEnv(process.env.RAZORPAY_KEY_ID);
  const keySecret = trimEnv(process.env.RAZORPAY_KEY_SECRET);

  if (!keyId || !keySecret || !/^rzp_(test|live)_[A-Za-z0-9]+$/.test(keyId)) {
    return sendError(res, 503, "Payment service is not configured.");
  }

  const body = req.body || {};
  const sessionId = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";
  const currency = typeof body.currency === "string" ? body.currency.toUpperCase() : detectCurrency(req);
  const confirmed = body.orderConfirmed === true;

  if (!sessionId || !sessionToken) {
    return sendError(res, 400, "Upload and preview are required before checkout.");
  }

  if (!confirmed) {
    return sendError(res, 400, "Please review and confirm your order summary before payment.");
  }

  const tokenData = validateSessionToken(sessionToken, getKeySecret());
  if (!tokenData || tokenData.sessionId !== sessionId) {
    return sendError(res, 400, "Upload session is invalid or expired. Upload your file again.");
  }

  const session = await loadSessionRecord(sessionId);
  if (!session || session.contentHash !== tokenData.contentHash) {
    return sendError(res, 400, "Upload session not found. Upload your file again.");
  }

  const planId = session.planTier || session.validation?.plan?.tier || "starter";
  const quote = buildOrderQuote(planId, currency);

  if (!quote.checkoutAvailable) {
    return sendError(
      res,
      403,
      quote.message ||
        "Enterprise assessment detected. Contact sales@aigovernancehub.ai for a guided assessment."
    );
  }

  const receipt = `agh_${planId}_${Date.now()}`;
  const orderPayload = {
    amount: quote.razorpayAmount,
    currency: quote.razorpayCurrency,
    receipt,
    notes: {
      product: `AI Governance Assessment — ${quote.plan.label}`,
      sessionId,
      planId,
    },
  };

  const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

  try {
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify(orderPayload),
    });

    const rawBody = await response.text();
    let order = {};
    try {
      order = rawBody ? JSON.parse(rawBody) : {};
    } catch {
      order = {};
    }

    if (!response.ok || !order.id || typeof order.amount !== "number" || !order.currency) {
      console.error("Razorpay create-order failed", { status: response.status, receipt });
      return sendError(res, 502, "Unable to create payment order.");
    }

    if (order.amount !== quote.razorpayAmount) {
      console.error("Razorpay amount mismatch", { expected: quote.razorpayAmount, actual: order.amount });
      return sendError(res, 502, "Unable to create payment order.");
    }

    await saveSessionRecord({
      ...session,
      pendingCheckout: {
        orderId: order.id,
        amountMinor: order.amount,
        currency: order.currency,
        planId,
        quote,
        createdAt: new Date().toISOString(),
      },
    });

    await logAudit(order.id, AUDIT_EVENTS.PAYMENT_STARTED, {
      sessionId,
      planId,
      amount: order.amount,
      currency: order.currency,
    });

    await trackEvent("checkout_started", req, { correlationId, orderId: order.id, sessionId, planId });

    return sendJson(res, 200, {
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId,
      orderSummary: quote,
    });
  } catch (error) {
    console.error("Razorpay create-order request error", {
      message: error instanceof Error ? error.message : "unknown",
    });
    return sendError(res, 500, "Unable to create payment order.");
  }
}
