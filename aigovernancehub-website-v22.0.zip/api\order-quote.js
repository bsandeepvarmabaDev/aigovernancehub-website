// AI Governance Hub API — order quote v21.0
import { getKeySecret, validateSessionToken } from "./lib/tokens.js";
import { loadSessionRecord } from "./lib/storage.js";
import { buildOrderQuote, detectCurrency } from "./lib/pricing.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  const body = req.body || {};
  const sessionId = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";
  const currencyOverride =
    typeof body.currency === "string" ? body.currency.toUpperCase() : detectCurrency(req);

  if (!sessionId || !sessionToken) {
    return sendError(res, 400, "Upload session is required.");
  }

  const tokenData = validateSessionToken(sessionToken, getKeySecret());
  if (!tokenData || tokenData.sessionId !== sessionId) {
    return sendError(res, 400, "Upload session is invalid or expired.");
  }

  const session = await loadSessionRecord(sessionId);
  if (!session || session.contentHash !== tokenData.contentHash) {
    return sendError(res, 404, "Upload session not found.");
  }

  const planId = session.planTier || session.validation?.plan?.tier || "starter";
  const quote = buildOrderQuote(planId, currencyOverride);

  return sendJson(res, 200, {
    correlationId,
    quote,
    planRecommendation: session.validation?.plan?.reason || null,
    compatibility: session.validation?.compatibility || null,
  });
}
