// AI Governance Hub API — verify-payment v25.7
import {
  getKeySecret,
  isNonEmptyString,
  validateSuccessToken,
  validateSessionToken,
  validateEnterprisePayToken,
} from "./lib/tokens.js";
import { getPlanById } from "./lib/assessment-config.js";
import { assertSelfServeAllowed, loadSalesRequestBySession } from "./lib/enterprise-gate.js";
import {
  assertStorageConfigured,
  loadReportRecord,
  loadSessionRecord,
} from "./lib/storage.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { isEmailConfigured } from "./lib/email.js";
import {
  verifyRazorpayPaymentSignature,
  fetchRazorpayPayment,
} from "./lib/razorpay-client.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";
import {
  buildVerifiedResponse,
  fulfillPaidAssessment,
} from "./lib/payment-fulfillment.js";

async function assertPaymentAmountMatches(paymentId, expectedAmountMinor, expectedCurrency) {
  const payment = await fetchRazorpayPayment(paymentId);
  if (payment.status !== "captured" && payment.status !== "authorized") {
    return false;
  }
  if (typeof payment.amount !== "number" || payment.amount !== expectedAmountMinor) {
    return false;
  }
  if (typeof payment.currency !== "string" || payment.currency.toUpperCase() !== expectedCurrency.toUpperCase()) {
    return false;
  }
  return true;
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Payment verification is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Payment verification is not configured.");
  }

  const body = req.body || {};
  const token =
    typeof body.confirmationToken === "string"
      ? body.confirmationToken
      : typeof body.successToken === "string"
        ? body.successToken
        : "";

  if (isNonEmptyString(token)) {
    const tokenData = validateSuccessToken(token, keySecret);
    if (!tokenData) {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    const report = await loadReportRecord(tokenData.orderId);
    if (!report || report.paymentId !== tokenData.paymentId || report.paymentStatus !== "verified") {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    return sendJson(res, 200, {
      valid: true,
      orderId: tokenData.orderId,
      paymentId: tokenData.paymentId,
      message: "Payment verified. Your full report is ready to download.",
      downloadReady: true,
      availableFormats: report.availableFormats || ["html", "text"],
      emailStatus: report.emailSent ? "sent" : report.emailError ? "failed" : "pending",
      emailConfigured: isEmailConfigured(),
    });
  }

  const rateLimited = await enforceRateLimit(req, "verify-payment", body.email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderId = body.razorpay_order_id;
  const paymentId = body.razorpay_payment_id;
  const signature = body.razorpay_signature;
  const name = body.name;
  const email = body.email;
  const company = typeof body.company === "string" ? body.company.trim() : "";
  const sessionId = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";
  const enterprisePayToken =
    typeof body.enterprisePayToken === "string" ? body.enterprisePayToken : "";

  if (!isNonEmptyString(orderId) || !isNonEmptyString(paymentId) || !isNonEmptyString(signature)) {
    return sendError(res, 400, "Invalid payment verification request.");
  }

  if (!isNonEmptyString(name) || !isNonEmptyString(email)) {
    return sendError(res, 400, "Missing required contact details.");
  }

  if (!sessionId) {
    return sendError(res, 400, "Upload session is required for report delivery.");
  }

  if (!verifyRazorpayPaymentSignature(orderId, paymentId, signature, keySecret)) {
    return sendError(res, 400, "Payment verification failed.");
  }

  const session = await loadSessionRecord(sessionId);
  if (!session) {
    return sendError(res, 400, "Upload session not found. Upload your file again.");
  }

  const enterpriseTokenData = validateEnterprisePayToken(enterprisePayToken, keySecret);
  const isEnterprisePayFlow =
    enterpriseTokenData &&
    enterpriseTokenData.sessionId === sessionId &&
    enterpriseTokenData.orderId === orderId;

  const sessionTokenData = validateSessionToken(sessionToken, keySecret);
  if (!isEnterprisePayFlow) {
    if (!sessionToken || !sessionTokenData || sessionTokenData.sessionId !== sessionId) {
      return sendError(res, 400, "Upload session is invalid or expired.");
    }
    if (session.contentHash !== sessionTokenData.contentHash) {
      return sendError(res, 400, "Upload session not found. Upload your file again.");
    }
  }

  const salesRequest = await loadSalesRequestBySession(sessionId);
  const isEnterpriseOrder = salesRequest?.customOrderId === orderId || isEnterprisePayFlow;
  const gateCheck = assertSelfServeAllowed(session);
  if (!gateCheck.allowed && !isEnterpriseOrder) {
    return sendError(res, 403, gateCheck.reason);
  }

  if (!isEnterpriseOrder) {
    if (!session.pendingCheckout || session.pendingCheckout.orderId !== orderId) {
      return sendError(res, 400, "Payment verification failed.");
    }
  }

  const existingReport = await loadReportRecord(orderId);
  if (
    existingReport &&
    existingReport.paymentStatus === "verified" &&
    existingReport.paymentId === paymentId
  ) {
    if (existingReport.sessionId && existingReport.sessionId !== sessionId) {
      return sendError(res, 400, "Payment verification failed.");
    }
    return sendJson(res, 200, {
      ...(await buildVerifiedResponse(existingReport, keySecret)),
      emailStatus: existingReport.emailSent ? "sent" : "failed",
    });
  }

  if (!isEnterpriseOrder) {
    const checkout = session.pendingCheckout;
    try {
      const amountOk = await assertPaymentAmountMatches(
        paymentId,
        checkout.amountMinor,
        checkout.currency
      );
      if (!amountOk) {
        return sendError(res, 400, "Payment verification failed.");
      }
    } catch {
      return sendError(res, 502, "Payment verification is temporarily unavailable.");
    }
  } else if (salesRequest?.quoteAmountMinor && salesRequest?.quoteCurrency) {
    try {
      const amountOk = await assertPaymentAmountMatches(
        paymentId,
        salesRequest.quoteAmountMinor,
        salesRequest.quoteCurrency
      );
      if (!amountOk) {
        return sendError(res, 400, "Payment verification failed.");
      }
    } catch {
      return sendError(res, 502, "Payment verification is temporarily unavailable.");
    }
  }

  const planTier = session.planTier || session.pendingCheckout?.planId || "starter";
  const plan = getPlanById(planTier);

  const { report } = await fulfillPaidAssessment({
    session,
    sessionId,
    orderId,
    paymentId,
    name,
    email,
    company,
    industry: session.industry || body.industry,
    keySecret,
    req,
    correlationId,
    paymentProvider: "razorpay",
    isEnterpriseOrder,
  });

  return sendJson(res, 200, {
    ...(await buildVerifiedResponse(report, keySecret)),
    emailStatus: report.emailSent ? "sent" : "failed",
    planLabel: plan.label,
  });
}
