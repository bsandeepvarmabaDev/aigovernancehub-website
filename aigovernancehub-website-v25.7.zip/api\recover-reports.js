// AI Governance Hub API — recover-reports v25.7
import { getKeySecret, isNonEmptyString } from "./lib/tokens.js";
import {
  assertStorageConfigured,
  listReportIdsForEmail,
  loadReportRecord,
  normalizeEmail,
} from "./lib/storage.js";
import { createMagicLinkRecord } from "./lib/auth.js";
import { sendMagicLinkEmail, isEmailConfigured } from "./lib/email.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./lib/audit.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { trackEvent } from "./lib/analytics.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Recovery service is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Recovery service is not configured.");
  }

  const body = req.body || {};
  const email = normalizeEmail(body.email);

  if (!isNonEmptyString(email) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return sendError(res, 400, "A valid email address is required.");
  }

  const rateLimited = await enforceRateLimit(req, "recover-reports", email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderIds = await listReportIdsForEmail(email, keySecret);
  let activeReportCount = 0;

  for (const orderId of orderIds) {
    const report = await loadReportRecord(orderId);
    if (!report || report.paymentStatus !== "verified" || report.buyerEmail !== email) {
      continue;
    }

    const expiresAt = report.expiresAt ? Date.parse(report.expiresAt) : null;
    if (expiresAt && Date.now() > expiresAt) {
      continue;
    }

    activeReportCount += 1;
    await logAudit(orderId, AUDIT_EVENTS.REPORT_RECOVERED, { email, channel: "email_verification" });
  }

  if (activeReportCount > 0 && isEmailConfigured()) {
    try {
      const { token } = await createMagicLinkRecord(email);
      const magicUrl = `${getSiteUrl()}/login.html?token=${encodeURIComponent(token)}&redirect=${encodeURIComponent("/dashboard.html")}`;
      await sendMagicLinkEmail(email, magicUrl);
    } catch {
      return sendError(res, 500, "Unable to send recovery link.");
    }
  }

  await trackEvent("recovery_used", req, { correlationId, reportCount: activeReportCount });

  return sendJson(res, 200, {
    message:
      "If purchased reports exist for this email, a secure sign-in link has been sent. Check your inbox and spam folder.",
    emailConfigured: isEmailConfigured(),
    requiresEmailVerification: true,
  });
}
