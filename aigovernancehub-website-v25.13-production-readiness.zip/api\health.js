// AI Governance Hub API — health / readiness v25.13
import { applySecurityHeaders, sendJson } from "./lib/security.js";
import {
  getCorrelationId,
  getRequestId,
  attachRequestHeaders,
  createRequestLogger,
} from "./lib/correlation.js";
import { getPublicReadiness } from "./lib/ops-readiness.js";
import { recordOpsTiming } from "./lib/ops-metrics.js";

export default async function handler(req, res) {
  const startedAt = Date.now();
  const correlationId = getCorrelationId(req);
  const requestId = getRequestId(req);
  attachRequestHeaders(res, { correlationId, requestId });
  applySecurityHeaders(res);

  const logger = createRequestLogger({
    correlationId,
    requestId,
    route: "/api/health",
  });

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    logger.finish("error", { statusCode: 405, category: "health" });
    return sendJson(res, 405, { error: "Method not allowed." });
  }

  const readiness = await getPublicReadiness();
  const statusCode = readiness.status === "unavailable" ? 503 : 200;

  await recordOpsTiming("health_check_ms", Date.now() - startedAt);
  logger.finish(readiness.status === "ok" ? "success" : "degraded", {
    statusCode,
    category: "health",
  });

  return sendJson(res, statusCode, {
    status: readiness.status,
    readiness: readiness.readiness,
    services: readiness.services,
    version: "25.13",
    correlationId,
    requestId,
    timestamp: new Date().toISOString(),
  });
}
