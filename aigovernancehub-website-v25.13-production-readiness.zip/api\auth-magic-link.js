// AI Governance Hub API — auth magic link v18.0
import {
  assertStorageConfigured,
} from "./lib/storage.js";
import {
  createMagicLinkRecord,
  isValidEmail,
  normalizeAuthEmail,
} from "./lib/auth.js";
import { sendMagicLinkEmail } from "./lib/email.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { trackEvent } from "./lib/analytics.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation, logEvent } from "./lib/correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Authentication is temporarily unavailable.");
  }

  const body = req.body || {};
  const email = normalizeAuthEmail(body.email);
  const redirect = typeof body.redirect === "string" ? body.redirect : "/dashboard.html";

  if (!isValidEmail(email)) {
    return sendError(res, 400, "A valid email address is required.");
  }

  const rateLimited = await enforceRateLimit(req, "auth-magic-link", email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  try {
    const { token } = await createMagicLinkRecord(email);
    const magicUrl = `${getSiteUrl()}/login.html?token=${encodeURIComponent(token)}&redirect=${encodeURIComponent(redirect)}`;
    const emailResult = await sendMagicLinkEmail(email, magicUrl);
    await trackEvent("magic_link_requested", req, { correlationId });
    logEvent("info", "magic_link_requested", { correlationId, emailHash: email.slice(0, 3) + "***" });

    return sendJson(res, 200, {
      message: "If an account exists for this email, a sign-in link has been sent.",
      emailConfigured: emailResult.sent,
    });
  } catch {
    return sendError(res, 500, "Unable to send sign-in link.");
  }
}
