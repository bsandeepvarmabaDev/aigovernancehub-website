// AI Governance Hub API — auth session v18.0
import { requireAuth } from "./lib/auth.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return sendError(res, 405, "Method not allowed.");
  }

  const session = await requireAuth(req);
  if (!session) {
    return sendJson(res, 401, { authenticated: false });
  }

  return sendJson(res, 200, {
    authenticated: true,
    email: session.email,
  });
}
