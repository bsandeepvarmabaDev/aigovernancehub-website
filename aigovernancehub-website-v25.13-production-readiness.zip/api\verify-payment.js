// AI Governance Hub API — verify-payment v25.8
import {
  getKeySecret,
  isNonEmptyString,
  validateSuccessToken,
  validateSessionToken,
  validateEnterprisePayToken,
} from "./lib/tokens.js";
import { getPlanById } from "./lib/assessment-config.js";
import { assertSelfServeAllowed, loadSalesRequestBySession } from "./lib/enterprise-gate.js";
import {
  assertStorageConfigured,
  loadReportRecord,
  loadSessionRecord,
} from "./lib/storage.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { isEmailConfigured } from "./lib/email.js";
import { verifyRazorpayPaymentSignature } from "./lib/razorpay-client.js";
import { assertPaymentAmountMatches } from "./lib/payment-reconcile.js";
import { isPendingCheckoutExpired, PAYMENT_STATE, REPORT_STATE } from "./lib/payment-state.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, getRequestId, attachRequestHeaders, createRequestLogger, hashCustomerIdentifier, logEvent } from "./lib/correlation.js";
import { emitAlert, ALERT_TYPES } from "./lib/alerting.js";
import { incrementOpsCounter, recordOpsTiming } from "./lib/ops-metrics.js";
import { AUDIT_EVENTS, logAudit } from "./lib/audit.js";
import {
  buildVerifiedResponse,
  fulfillPaidAssessment,
} from "./lib/payment-fulfillment.js";

export default async function handler(req, res) {
  const startedAt = Date.now();
  const correlationId = getCorrelationId(req);
  const requestId = getRequestId(req);
  attachRequestHeaders(res, { correlationId, requestId });
  applySecurityHeaders(res);

  const bodyEarly = req.body || {};
  const logger = createRequestLogger({
    correlationId,
    requestId,
    route: "/api/verify-payment",
    assessmentId: typeof bodyEarly.sessionId === "string" ? bodyEarly.sessionId.trim() : null,
    customerHash: hashCustomerIdentifier(bodyEarly.email),
  });

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Payment verification is temporarily unavailable.");
  }

  const keySecret = getKeySecret();
  if (!keySecret) {
    return sendError(res, 503, "Payment verification is not configured.");
  }

  const body = req.body || {};
  const token =
    typeof body.confirmationToken === "string"
      ? body.confirmationToken
      : typeof body.successToken === "string"
        ? body.successToken
        : "";

  if (isNonEmptyString(token)) {
    const tokenData = validateSuccessToken(token, keySecret);
    if (!tokenData) {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    const report = await loadReportRecord(tokenData.orderId);
    if (
      !report ||
      report.paymentId !== tokenData.paymentId ||
      (report.paymentStatus !== "verified" && report.reportStatus !== REPORT_STATE.READY)
    ) {
      return sendJson(res, 400, {
        valid: false,
        error: "Confirmation token is invalid or expired.",
      });
    }

    return sendJson(res, 200, {
      valid: true,
      orderId: tokenData.orderId,
      paymentId: tokenData.paymentId,
      message:
        report.reportStatus === REPORT_STATE.GENERATING
          ? "Payment verified. Your report is being prepared."
          : "Payment verified. Your full report is ready to download.",
      downloadReady: report.reportStatus === REPORT_STATE.READY || report.paymentStatus === "verified",
      availableFormats: report.availableFormats || ["html", "text"],
      emailStatus: report.emailSent ? "sent" : report.emailError ? "failed" : "pending",
      emailConfigured: isEmailConfigured(),
      reportStatus: report.reportStatus || REPORT_STATE.READY,
    });
  }

  const rateLimited = await enforceRateLimit(req, "verify-payment", body.email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderId = body.razorpay_order_id;
  const paymentId = body.razorpay_payment_id;
  const signature = body.razorpay_signature;
  const name = body.name;
  const email = body.email;
  const company = typeof body.company === "string" ? body.company.trim() : "";
  const sessionId = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionToken = typeof body.sessionToken === "string" ? body.sessionToken : "";
  const enterprisePayToken =
    typeof body.enterprisePayToken === "string" ? body.enterprisePayToken : "";

  if (!isNonEmptyString(orderId) || !isNonEmptyString(paymentId) || !isNonEmptyString(signature)) {
    return sendError(res, 400, "Invalid payment verification request.");
  }

  if (!isNonEmptyString(name) || !isNonEmptyString(email)) {
    return sendError(res, 400, "Missing required contact details.");
  }

  if (!sessionId) {
    return sendError(res, 400, "Upload session is required for report delivery.");
  }

  if (!verifyRazorpayPaymentSignature(orderId, paymentId, signature, keySecret)) {
    await incrementOpsCounter("payment_verify_failed");
    await emitAlert(ALERT_TYPES.PAYMENT_VERIFY_FAILED, { correlationId, requestId, orderId });
    logger.finish("error", { statusCode: 400, category: "payment" });
    return sendError(res, 400, "Payment verification failed.");
  }

  const session = await loadSessionRecord(sessionId);
  if (!session) {
    return sendError(res, 400, "Upload session not found. Upload your file again.");
  }

  const enterpriseTokenData = validateEnterprisePayToken(enterprisePayToken, keySecret);
  const isEnterprisePayFlow =
    enterpriseTokenData &&
    enterpriseTokenData.sessionId === sessionId &&
    enterpriseTokenData.orderId === orderId;

  const sessionTokenData = validateSessionToken(sessionToken, keySecret);
  if (!isEnterprisePayFlow) {
    if (!sessionToken || !sessionTokenData || sessionTokenData.sessionId !== sessionId) {
      return sendError(res, 400, "Upload session is invalid or expired.");
    }
    if (session.contentHash !== sessionTokenData.contentHash) {
      return sendError(res, 400, "Upload session not found. Upload your file again.");
    }
  }

  const salesRequest = await loadSalesRequestBySession(sessionId);
  const isEnterpriseOrder = salesRequest?.customOrderId === orderId || isEnterprisePayFlow;
  const gateCheck = assertSelfServeAllowed(session);
  if (!gateCheck.allowed && !isEnterpriseOrder) {
    return sendError(res, 403, gateCheck.reason);
  }

  if (!isEnterpriseOrder) {
    if (!session.pendingCheckout || session.pendingCheckout.orderId !== orderId) {
      return sendError(res, 400, "Payment verification failed.");
    }
    if (isPendingCheckoutExpired(session.pendingCheckout)) {
      logEvent("warn", "pending_checkout_expired", { correlationId, orderId, sessionId, category: "payment" });
      return sendError(res, 400, "Checkout session expired. Please start checkout again.");
    }
  }

  const existingReport = await loadReportRecord(orderId);
  if (
    existingReport &&
    existingReport.paymentStatus === "verified" &&
    existingReport.paymentId === paymentId &&
    existingReport.reportStatus === REPORT_STATE.READY
  ) {
    if (existingReport.sessionId && existingReport.sessionId !== sessionId) {
      return sendError(res, 400, "Payment verification failed.");
    }
    return sendJson(res, 200, {
      ...(await buildVerifiedResponse(existingReport)),
      emailStatus: existingReport.emailSent ? "sent" : "failed",
    });
  }

  if (!isEnterpriseOrder) {
    const checkout = session.pendingCheckout;
    try {
      const amountCheck = await assertPaymentAmountMatches(
        paymentId,
        checkout.amountMinor,
        checkout.currency
      );
      if (!amountCheck.ok) {
        return sendError(res, 400, "Payment verification failed.");
      }
    } catch (error) {
      logEvent("error", "razorpay_fetch_failed", {
        correlationId,
        category: "reliability",
        message: error instanceof Error ? error.message : "unknown",
      });
      return sendError(res, 502, "Payment verification is temporarily unavailable.");
    }
  } else if (salesRequest?.quoteAmountMinor && salesRequest?.quoteCurrency) {
    try {
      const amountCheck = await assertPaymentAmountMatches(
        paymentId,
        salesRequest.quoteAmountMinor,
        salesRequest.quoteCurrency
      );
      if (!amountCheck.ok) {
        return sendError(res, 400, "Payment verification failed.");
      }
    } catch (error) {
      logEvent("error", "razorpay_fetch_failed", {
        correlationId,
        category: "reliability",
        message: error instanceof Error ? error.message : "unknown",
      });
      return sendError(res, 502, "Payment verification is temporarily unavailable.");
    }
  }

  const planTier = session.planTier || session.pendingCheckout?.planId || "starter";
  const plan = getPlanById(planTier);

  let report;
  try {
    const result = await fulfillPaidAssessment({
      session,
      sessionId,
      orderId,
      paymentId,
      name,
      email,
      company,
      industry: session.industry || body.industry,
      keySecret,
      req,
      correlationId,
      paymentProvider: "razorpay",
      isEnterpriseOrder,
    });
    report = result.report;
  } catch {
    await recordOpsTiming("payment_verify_ms", Date.now() - startedAt);
    logger.finish("error", { statusCode: 202, category: "report_generation" });
    return sendJson(res, 202, {
      success: true,
      paymentState: PAYMENT_STATE.PAID,
      reportStatus: REPORT_STATE.FAILED,
      message:
        "Payment received. Report generation encountered an issue — our team has been notified. Contact support@aigovernancehub.ai with your order reference.",
      orderId,
      paymentId,
      emailConfigured: isEmailConfigured(),
    });
  }

  await incrementOpsCounter("payment_verified");
  await recordOpsTiming("payment_verify_ms", Date.now() - startedAt);
  logger.finish("success", { statusCode: 200, assessmentId: sessionId });

  return sendJson(res, 200, {
    ...(await buildVerifiedResponse(report)),
    emailStatus: report.emailSent ? "sent" : "failed",
    planLabel: plan.label,
    correlationId,
    requestId,
  });
}
