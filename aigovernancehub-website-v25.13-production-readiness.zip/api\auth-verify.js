// AI Governance Hub API — auth verify v18.0
import { assertStorageConfigured } from "./lib/storage.js";
import {
  consumeMagicLink,
  createAuthSessionRecord,
  setSessionCookie,
} from "./lib/auth.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { enforceRateLimit } from "./lib/rate-limit.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Authentication is temporarily unavailable.");
  }

  const body = req.body || {};
  const token = typeof body.token === "string" ? body.token : "";

  if (!token) {
    return sendError(res, 400, "Sign-in token is required.");
  }

  const rateLimited = await enforceRateLimit(req, "auth-verify");
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const email = await consumeMagicLink(token);
  if (!email) {
    return sendError(res, 400, "Sign-in link is invalid or expired.");
  }

  const session = await createAuthSessionRecord(email);
  setSessionCookie(res, session.cookieValue);

  return sendJson(res, 200, {
    authenticated: true,
    email: session.email,
  });
}
