// AI Governance Hub API — health v18.0
import { isStorageConfigured, getStorageBackendName } from "./lib/storage.js";
import { isEmailConfigured } from "./lib/email.js";
import { trimEnv } from "./lib/tokens.js";
import { applySecurityHeaders, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation, logEvent } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return sendJson(res, 405, { error: "Method not allowed." });
  }

  const healthy = isStorageConfigured() && Boolean(trimEnv(process.env.RAZORPAY_KEY_ID) && trimEnv(process.env.RAZORPAY_KEY_SECRET));
  logEvent(healthy ? "info" : "warn", "health_check", {
    correlationId,
    storage: isStorageConfigured(),
    email: isEmailConfigured(),
    backend: getStorageBackendName(),
  });

  return sendJson(res, healthy ? 200 : 503, {
    status: healthy ? "ok" : "degraded",
    version: "25.8",
    correlationId,
    timestamp: new Date().toISOString(),
  });
}
