// AI Governance Hub API — customer dashboard v24.0
import { createRecoveryToken, getEmailIndexSecret } from "./lib/tokens.js";
import { listReportIdsForEmail, loadReportRecord, maskOrderId, maskPaymentId } from "./lib/storage.js";
import { requireAuth } from "./lib/auth.js";
import { trackEvent } from "./lib/analytics.js";
import { applySecurityHeaders, sendError, sendJson } from "./lib/security.js";
import { getCorrelationId, attachCorrelation } from "./lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return sendError(res, 405, "Method not allowed.");
  }

  const session = await requireAuth(req);
  if (!session) {
    return sendError(res, 401, "Sign in required.");
  }

  const indexSecret = getEmailIndexSecret();
  if (!indexSecret) {
    return sendError(res, 503, "Dashboard is not configured.");
  }
  const orderIds = await listReportIdsForEmail(session.email, indexSecret);
  const reports = [];

  for (const orderId of orderIds) {
    const report = await loadReportRecord(orderId);
    if (!report || report.buyerEmail !== session.email) continue;
    const recoveryToken = createRecoveryToken(orderId, report.paymentId, session.email, indexSecret);
    reports.push({
      orderRef: maskOrderId(orderId),
      assessmentId: maskOrderId(orderId),
      purchasedAt: report.createdAt,
      uploadDate: report.uploadDate || report.createdAt,
      paymentStatus: report.paymentStatus,
      reportStatus: report.reportStatus || (report.paymentStatus === "verified" ? "ready" : "pending"),
      planTier: report.planTier || "starter",
      planLabel: report.planLabel || "Starter",
      workItemCount: report.workItemCount ?? report.preview?.totalRecords ?? null,
      detectedPlatform: report.detectedPlatform || report.intelligenceSnapshot?.source || null,
      paymentRef: report.paymentId ? maskPaymentId(report.paymentId) : null,
      reportVersion: report.reportVersion || "24.0",
      industry: report.industry || report.intelligenceSnapshot?.industry || "general",
      projectLabel: report.intelligenceSnapshot?.projectLabel || report.company || maskOrderId(orderId),
      governanceScore: report.governanceScore ?? report.preview?.governanceScore ?? null,
      aiReadiness: report.aiReadiness ?? report.preview?.aiReadiness ?? null,
      availableFormats: report.availableFormats || ["html", "text"],
      downloadCount: Number(report.downloadCount || 0),
      lastDownloadAt: report.lastDownloadAt,
      emailSent: Boolean(report.emailSent),
      expiresAt: report.expiresAt,
      downloadDisabled: Boolean(report.downloadDisabled),
      recoveryToken,
      invoiceAvailable: report.paymentStatus === "verified",
    });
  }

  reports.sort((a, b) => new Date(b.purchasedAt) - new Date(a.purchasedAt));

  await trackEvent("dashboard_viewed", req, { correlationId });

  res.setHeader("Cache-Control", "private, max-age=30");

  return sendJson(res, 200, {
    email: session.email,
    version: "25.17",
    reports,
    intelligenceUrl: "/api/portfolio",
    actionTrackerUrl: "/api/action-tracker",
  });
}
