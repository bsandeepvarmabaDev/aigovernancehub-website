// AI Governance Hub API — razorpay-webhook v25.8
import {
  verifyRazorpayWebhookSignature,
  isRazorpayConfigured,
} from "./_lib/razorpay-client.js";
import {
  assertStorageConfigured,
  isWebhookEventProcessed,
  markWebhookEventProcessed,
} from "./_lib/storage.js";
import { enforceRateLimit } from "./_lib/rate-limit.js";
import { reconcileWebhookPayment } from "./_lib/payment-reconcile.js";
import { AUDIT_EVENTS, logAudit } from "./_lib/audit.js";
import { applySecurityHeaders, sendError, sendJson } from "./_lib/security.js";
import { getCorrelationId, attachCorrelation, logEvent } from "./_lib/correlation.js";

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  if (!isRazorpayConfigured()) {
    return sendError(res, 503, "Webhook service is not configured.");
  }

  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Webhook service is temporarily unavailable.");
  }

  const rateLimited = await enforceRateLimit(req, "razorpay-webhook");
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const signature =
    req.headers["x-razorpay-signature"] ||
    req.headers["X-Razorpay-Signature"] ||
    "";

  const rawBody =
    typeof req.body === "string"
      ? req.body
      : Buffer.isBuffer(req.body)
        ? req.body.toString("utf8")
        : JSON.stringify(req.body || {});

  if (!verifyRazorpayWebhookSignature(rawBody, String(signature))) {
    logEvent("warn", "webhook_signature_invalid", { correlationId, category: "security" });
    return sendError(res, 400, "Invalid webhook signature.");
  }

  let payload = {};
  try {
    payload = typeof req.body === "object" && req.body !== null && !Buffer.isBuffer(req.body)
      ? req.body
      : JSON.parse(rawBody);
  } catch {
    return sendError(res, 400, "Invalid webhook payload.");
  }

  const eventId = payload.event_id || payload.id || `${payload.event}:${payload.created_at}`;
  const eventType = payload.event;
  const paymentEntity = payload.payload?.payment?.entity || payload.payload?.order?.entity;

  if (!eventType) {
    return sendError(res, 400, "Unsupported webhook event.");
  }

  if (await isWebhookEventProcessed(eventId)) {
    logEvent("info", "webhook_duplicate_ignored", { correlationId, eventId, eventType });
    return sendJson(res, 200, { received: true, duplicate: true });
  }

  try {
    const result = await reconcileWebhookPayment({
      eventId,
      eventType,
      paymentEntity,
      correlationId,
    });

    if (paymentEntity?.order_id) {
      await logAudit(paymentEntity.order_id, AUDIT_EVENTS.PAYMENT_WEBHOOK, {
        eventId,
        eventType,
        correlationId,
        handled: result.handled,
        state: result.state,
      });
    }

    await markWebhookEventProcessed(eventId, {
      eventType,
      correlationId,
      handled: result.handled,
    });

    logEvent("info", "webhook_processed", {
      correlationId,
      eventId,
      eventType,
      category: "payment",
      handled: result.handled,
    });

    return sendJson(res, 200, { received: true, ...result });
  } catch (error) {
    logEvent("error", "webhook_processing_failed", {
      correlationId,
      eventId,
      eventType,
      category: "reliability",
      message: error instanceof Error ? error.message : "unknown",
    });
    return sendError(res, 500, "Webhook processing failed.");
  }
}
