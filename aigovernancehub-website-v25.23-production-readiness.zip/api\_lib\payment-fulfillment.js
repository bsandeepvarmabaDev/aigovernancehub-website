/**
 * Shared post-payment fulfillment — Razorpay (server-verified) v25.8
 */
import {
  createRecoveryToken,
  createSuccessToken,
  getDownloadSigningSecret,
  getEmailIndexSecret,
  getKeySecret,
} from "./tokens.js";
import { generateHtmlReport, generateTextReport } from "./report-engine.js";
import { generateAllExecutiveFormatsV24 } from "./report-export-v24.js";
import { applyIndustryModel, normalizeIndustry } from "./industry-models.js";
import { buildIntelligenceSnapshot } from "./intelligence-snapshot.js";
import { hashEmailForAnalytics } from "./platform-analytics.js";
import { getPlanById } from "./assessment-config.js";
import {
  loadSalesRequestBySession,
  saveSalesRequest,
  markEnterpriseReportDelivered,
  ENTERPRISE_STATUS,
} from "./enterprise-gate.js";
import {
  getReportExpiresAt,
  indexReportForEmail,
  indexPaymentOrder,
  indexSessionOrder,
  loadReportRecord,
  loadSessionRecord,
  maskOrderId,
  maskPaymentId,
  saveReportContent,
  saveReportRecord,
} from "./storage.js";
import { getClientIp, hashIp } from "./rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./audit.js";
import { sendPaymentEmails } from "./email.js";
import { trackEvent } from "./analytics.js";
import { PAYMENT_STATE, REPORT_STATE } from "./payment-state.js";
import { incrementOpsCounter, recordOpsTiming } from "./ops-metrics.js";
import { emitAlert, ALERT_TYPES } from "./alerting.js";
import { logEvent } from "./correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

export async function buildVerifiedResponse(report) {
  const downloadSecret = getDownloadSigningSecret();
  const confirmationToken = createSuccessToken(report.orderId, report.paymentId, downloadSecret);
  const recoveryToken = createRecoveryToken(
    report.orderId,
    report.paymentId,
    report.buyerEmail,
    downloadSecret
  );

  return {
    success: true,
    valid: true,
    confirmationToken,
    recoveryToken,
    orderId: report.orderId,
    paymentId: report.paymentId,
    message: "Payment verified. Your full report is ready to download.",
    downloadReady: report.reportStatus === REPORT_STATE.READY,
    availableFormats: report.availableFormats || ["html", "text"],
    emailStatus: report.emailSent ? "sent" : report.emailError ? "failed" : "pending",
    reportStatus: report.reportStatus || REPORT_STATE.READY,
  };
}

async function saveGeneratingStub({
  session,
  sessionId,
  orderId,
  paymentId,
  name,
  email,
  company,
  industry,
  paymentProvider,
  planTier,
  plan,
}) {
  const createdAt = new Date().toISOString();
  return {
    orderId,
    paymentId,
    sessionId,
    buyerName: name,
    buyerEmail: email,
    company: company || null,
    filename: session.filename,
    uploadDate: session.createdAt || createdAt,
    workItemCount: session.workItemMetrics?.totalWorkItems ?? session.preview?.totalRecords ?? null,
    detectedPlatform: session.source,
    industry: normalizeIndustry(industry || session.industry),
    planTier,
    planLabel: plan.label,
    paymentProvider,
    paymentState: PAYMENT_STATE.PAID,
    paymentStatus: "pending",
    reportStatus: REPORT_STATE.GENERATING,
    createdAt,
    expiresAt: getReportExpiresAt(new Date(createdAt)),
    downloadCount: 0,
    emailSent: false,
    emailError: null,
    preview: session.preview,
  };
}

async function generateReportArtifacts(session, reportMeta, normalizedIndustry) {
  const executiveRaw = session.executiveAssessment;
  const executive = executiveRaw ? applyIndustryModel(executiveRaw, normalizedIndustry) : null;
  let availableFormats = ["html", "text"];

  if (executive) {
    const formats = await generateAllExecutiveFormatsV24(executive, reportMeta);
    await saveReportContent(reportMeta.orderId, formats.html, formats.text, {
      pdf: formats.pdf,
      docx: formats.docx,
      pptx: formats.pptx,
    });
    availableFormats = ["html", "text", "pdf", "docx", "pptx"];
  } else {
    const html = generateHtmlReport(session.analysis, reportMeta);
    const text = generateTextReport(session.analysis, reportMeta);
    await saveReportContent(reportMeta.orderId, html, text);
  }

  return { executive, availableFormats };
}

/**
 * Idempotent — returns existing report if already verified and ready.
 */
export async function fulfillPaidAssessment({
  session,
  sessionId,
  orderId,
  paymentId,
  name,
  email,
  company = "",
  industry,
  keySecret,
  req,
  correlationId,
  paymentProvider = "razorpay",
  isEnterpriseOrder = false,
  forceRegenerate = false,
}) {
  const existingReport = await loadReportRecord(orderId);
  if (
    existingReport?.paymentStatus === "verified" &&
    existingReport?.reportStatus === REPORT_STATE.READY &&
    !forceRegenerate
  ) {
    return { report: existingReport, alreadyFulfilled: true };
  }

  const createdAt = existingReport?.createdAt || new Date().toISOString();
  const planTier = session.planTier || session.pendingCheckout?.planId || "starter";
  const plan = getPlanById(planTier);
  const normalizedIndustry = normalizeIndustry(industry || session.industry);
  const analyticsSecret = getEmailIndexSecret();

  const stub = await saveGeneratingStub({
    session,
    sessionId,
    orderId,
    paymentId,
    name,
    email,
    company,
    industry,
    paymentProvider,
    planTier,
    plan,
  });
  await saveReportRecord({ ...stub, ...(existingReport || {}) });

  const reportMeta = {
    buyerName: name,
    buyerEmail: email,
    company,
    orderId,
    paymentId,
    orderRef: maskOrderId(orderId),
    paymentRef: maskPaymentId(paymentId),
    paidAt: createdAt,
    planTier,
    planLabel: plan.label,
  };

  let executive;
  let availableFormats = ["html", "text"];

  try {
    const generated = await generateReportArtifacts(session, reportMeta, normalizedIndustry);
    executive = generated.executive;
    availableFormats = generated.availableFormats;
  } catch (error) {
    const failedRecord = {
      ...(await loadReportRecord(orderId)),
      paymentState: PAYMENT_STATE.PAID,
      paymentStatus: "paid",
      reportStatus: REPORT_STATE.FAILED,
      reportError: error instanceof Error ? error.message : "Report generation failed.",
      updatedAt: new Date().toISOString(),
    };
    await saveReportRecord(failedRecord);
    await logAudit(orderId, AUDIT_EVENTS.REPORT_GENERATION_FAILED, {
      sessionId,
      correlationId,
      category: "reliability",
    });
    await incrementOpsCounter("report_generation_failed");
    await emitAlert(ALERT_TYPES.REPORT_GENERATION_FAILED, { orderId, correlationId, sessionId });
    logEvent("error", "report_generation_failed", {
      orderId,
      correlationId,
      category: "reliability",
      message: failedRecord.reportError,
    });
    throw error;
  }

  const intelligenceSnapshot = executive
    ? buildIntelligenceSnapshot(executive, {
        orderId,
        orderRef: maskOrderId(orderId),
        paidAt: createdAt,
        industry: normalizedIndustry,
        source: session.source,
        company,
        planTier,
        planLabel: plan.label,
      })
    : null;

  const reportRecord = {
    orderId,
    paymentId,
    sessionId,
    buyerName: name,
    buyerEmail: email,
    company: company || null,
    filename: session.filename,
    uploadDate: session.createdAt || createdAt,
    workItemCount: session.workItemMetrics?.totalWorkItems ?? session.preview?.totalRecords ?? null,
    detectedPlatform: session.source,
    industry: normalizedIndustry,
    planTier,
    planLabel: plan.label,
    reportVersion: executive ? "24.0" : "21.0",
    governanceScore:
      executive?.executiveSummary?.governanceScore ?? session.preview?.governanceScore ?? null,
    aiReadiness: executive?.executiveSummary?.aiReadiness ?? session.preview?.aiReadiness ?? null,
    availableFormats,
    intelligenceSnapshot,
    paymentProvider,
    paymentState: PAYMENT_STATE.PAID,
    paymentStatus: "verified",
    reportStatus: REPORT_STATE.READY,
    reportError: null,
    createdAt,
    expiresAt: getReportExpiresAt(new Date(createdAt)),
    downloadCount: existingReport?.downloadCount || 0,
    lastDownloadAt: existingReport?.lastDownloadAt || null,
    lastDownloadIpHash: existingReport?.lastDownloadIpHash || null,
    preview: session.preview,
    emailSent: false,
    emailError: null,
  };

  await saveReportRecord(reportRecord);
  await indexReportForEmail(email, orderId, analyticsSecret);
  await indexPaymentOrder(paymentId, orderId);
  await indexSessionOrder(sessionId, orderId);

  const salesRequest = await loadSalesRequestBySession(sessionId);
  if (salesRequest && isEnterpriseOrder) {
    salesRequest.status = ENTERPRISE_STATUS.PAYMENT_RECEIVED;
    salesRequest.paidAt = createdAt;
    salesRequest.customOrderId = orderId;
    await saveSalesRequest(salesRequest);
    await markEnterpriseReportDelivered(salesRequest, orderId, "system");
  }

  await logAudit(orderId, AUDIT_EVENTS.PAYMENT_VERIFIED, {
    sessionId,
    email,
    paymentProvider,
    ipHash: req ? hashIp(getClientIp(req), keySecret) : null,
  });
  await logAudit(orderId, AUDIT_EVENTS.REPORT_GENERATED, { sessionId, email, paymentProvider });
  await incrementOpsCounter("report_generated");

  const siteUrl = getSiteUrl();
  let emailResult = { sent: false, reason: "Email not attempted." };
  try {
    emailResult = await sendPaymentEmails({
      buyerName: name,
      buyerEmail: email,
      company,
      orderRef: maskOrderId(orderId),
      paymentRef: maskPaymentId(paymentId),
      paidAt: createdAt,
      downloadUrl: `${siteUrl}/recover-report.html`,
      recoverUrl: `${siteUrl}/recover-report.html`,
      dashboardUrl: `${siteUrl}/dashboard.html`,
      governanceScore: reportRecord.governanceScore,
      topRecommendation:
        executive?.recommendations?.[0]?.title ||
        executive?.executiveSummary?.overallRecommendation ||
        null,
      planLabel: plan.label,
      availableFormats,
    });
  } catch (error) {
    emailResult = {
      sent: false,
      reason: error instanceof Error ? error.message : "Email delivery failed.",
    };
    logEvent("error", "payment_email_failed", {
      orderId,
      correlationId,
      category: "reliability",
      message: emailResult.reason,
    });
  }

  reportRecord.emailSent = emailResult.sent === true;
  reportRecord.emailError = emailResult.sent ? null : emailResult.reason || "Email not sent.";
  await saveReportRecord(reportRecord);

  if (emailResult.sent) {
    await logAudit(orderId, AUDIT_EVENTS.REPORT_EMAILED, { email });
  } else {
    await logAudit(orderId, AUDIT_EVENTS.REPORT_EMAIL_FAILED, {
      email,
      reason: reportRecord.emailError,
    });
    await incrementOpsCounter("report_email_failed");
    await emitAlert(ALERT_TYPES.SMTP_FAILURE, { orderId, correlationId, reason: reportRecord.emailError });
  }

  if (req) {
    await trackEvent("payment_verified", req, {
      correlationId,
      orderId,
      planTier,
      paymentProvider,
      emailHash: hashEmailForAnalytics(email, analyticsSecret),
    });
  }

  return { report: reportRecord, alreadyFulfilled: false };
}

export async function retryReportGeneration(orderId, correlationId) {
  const report = await loadReportRecord(orderId);
  if (!report) {
    throw new Error("Report not found.");
  }
  const session = await loadSessionRecord(report.sessionId);
  if (!session) {
    throw new Error("Upload session not found.");
  }

  const result = await fulfillPaidAssessment({
    session,
    sessionId: report.sessionId,
    orderId,
    paymentId: report.paymentId,
    name: report.buyerName,
    email: report.buyerEmail,
    company: report.company || "",
    industry: report.industry,
    keySecret: null,
    req: null,
    correlationId,
    paymentProvider: report.paymentProvider || "razorpay",
    isEnterpriseOrder: report.planTier === "enterprise",
    forceRegenerate: true,
  });

  await logAudit(orderId, AUDIT_EVENTS.REPORT_REGENERATED, { correlationId, admin: true });
  return result.report;
}

export function getKeySecretOrThrow() {
  const keySecret = getKeySecret();
  if (!keySecret) {
    throw new Error("Payment verification is not configured.");
  }
  return keySecret;
}
