/**
 * Canonical payment lifecycle states — v25.8
 */

export const PAYMENT_STATE = {
  PENDING: "pending",
  PAID: "paid",
  FAILED: "failed",
  CANCELLED: "cancelled",
  REFUNDED: "refunded",
  EXPIRED: "expired",
};

export const REPORT_STATE = {
  GENERATING: "generating",
  READY: "ready",
  FAILED: "failed",
};

/** Map legacy paymentStatus to canonical state. */
export function resolvePaymentState(record) {
  if (!record) return PAYMENT_STATE.PENDING;
  if (record.paymentState) return record.paymentState;
  if (record.paymentStatus === "verified") return PAYMENT_STATE.PAID;
  if (record.paymentStatus === "deleted") return PAYMENT_STATE.CANCELLED;
  return record.paymentStatus || PAYMENT_STATE.PENDING;
}

export function isDownloadReady(record) {
  if (!record) return false;
  if (record.downloadDisabled) return false;
  const state = resolvePaymentState(record);
  if (state === PAYMENT_STATE.REFUNDED || state === PAYMENT_STATE.CANCELLED) return false;
  if (state === PAYMENT_STATE.EXPIRED) return false;
  if (record.reportStatus === REPORT_STATE.FAILED) return false;
  return record.paymentStatus === "verified" || record.reportStatus === REPORT_STATE.READY;
}

export function isPendingCheckoutExpired(pendingCheckout) {
  if (!pendingCheckout) return true;
  if (pendingCheckout.expired) return true;
  const expiresAt = pendingCheckout.expiresAt ? Date.parse(pendingCheckout.expiresAt) : null;
  if (expiresAt && Date.now() > expiresAt) return true;
  return false;
}

export function terminalPaymentStates() {
  return [
    PAYMENT_STATE.PAID,
    PAYMENT_STATE.FAILED,
    PAYMENT_STATE.CANCELLED,
    PAYMENT_STATE.REFUNDED,
    PAYMENT_STATE.EXPIRED,
  ];
}

export function canTransitionPayment(from, to) {
  if (from === to) return true;
  const terminal = new Set([
    PAYMENT_STATE.REFUNDED,
    PAYMENT_STATE.CANCELLED,
    PAYMENT_STATE.EXPIRED,
  ]);
  if (terminal.has(from)) return false;
  if (to === PAYMENT_STATE.PENDING) return false;
  return true;
}
