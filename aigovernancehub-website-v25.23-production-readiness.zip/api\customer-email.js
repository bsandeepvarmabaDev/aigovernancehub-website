// AI Governance Hub API — magic link + report recovery (v25.23 Hobby bundle)
import { getEmailIndexSecret, isNonEmptyString } from "./_lib/tokens.js";
import {
  assertStorageConfigured,
  listReportIdsForEmail,
  loadReportRecord,
  normalizeEmail,
} from "./_lib/storage.js";
import {
  createMagicLinkRecord,
  isValidEmail,
  normalizeAuthEmail,
} from "./_lib/auth.js";
import { sendMagicLinkEmail, isEmailConfigured } from "./_lib/email.js";
import { enforceRateLimit } from "./_lib/rate-limit.js";
import { AUDIT_EVENTS, logAudit } from "./_lib/audit.js";
import { applySecurityHeaders, sendError, sendJson } from "./_lib/security.js";
import { trackEvent } from "./_lib/analytics.js";
import { getCorrelationId, attachCorrelation, logEvent } from "./_lib/correlation.js";

function getSiteUrl() {
  return (
    (typeof process.env.SITE_URL === "string" && process.env.SITE_URL.trim()) ||
    "https://aigovernancehub.ai"
  ).replace(/\/$/, "");
}

function getKind(req) {
  const queryKind =
    typeof req.query?.kind === "string" ? req.query.kind.trim().toLowerCase() : "";
  if (queryKind === "recover" || queryKind === "magic") {
    return queryKind;
  }
  return "magic";
}

async function handleMagicLink(req, res, correlationId) {
  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Authentication is temporarily unavailable.");
  }

  const body = req.body || {};
  const email = normalizeAuthEmail(body.email);
  const redirect = typeof body.redirect === "string" ? body.redirect : "/dashboard.html";

  if (!isValidEmail(email)) {
    return sendError(res, 400, "A valid email address is required.");
  }

  const rateLimited = await enforceRateLimit(req, "auth-magic-link", email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  try {
    const { token } = await createMagicLinkRecord(email);
    const magicUrl = `${getSiteUrl()}/login.html?token=${encodeURIComponent(token)}&redirect=${encodeURIComponent(redirect)}`;
    const emailResult = await sendMagicLinkEmail(email, magicUrl);
    await trackEvent("magic_link_requested", req, { correlationId });
    logEvent("info", "magic_link_requested", { correlationId, emailHash: email.slice(0, 3) + "***" });

    const emailConfigured = isEmailConfigured();
    return sendJson(res, 200, {
      message: emailResult.sent
        ? "If an account exists for this email, a sign-in link has been sent."
        : "Sign-in by email is temporarily unavailable. Use Recover My Report on this device or contact support@aigovernancehub.ai.",
      emailConfigured: emailResult.sent,
      emailDeliveryAvailable: emailConfigured,
    });
  } catch {
    return sendError(res, 500, "Unable to process sign-in request.");
  }
}

async function handleRecoverReports(req, res, correlationId) {
  try {
    assertStorageConfigured();
  } catch {
    return sendError(res, 503, "Recovery service is temporarily unavailable.");
  }

  const indexSecret = getEmailIndexSecret();
  if (!indexSecret) {
    return sendError(res, 503, "Recovery service is not configured.");
  }

  const body = req.body || {};
  const email = normalizeEmail(body.email);

  if (!isNonEmptyString(email) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return sendError(res, 400, "A valid email address is required.");
  }

  const rateLimited = await enforceRateLimit(req, "recover-reports", email);
  if (rateLimited) {
    return sendError(res, rateLimited.status, rateLimited.error);
  }

  const orderIds = await listReportIdsForEmail(email, indexSecret);
  let activeReportCount = 0;

  for (const orderId of orderIds) {
    const report = await loadReportRecord(orderId);
    if (!report || report.paymentStatus !== "verified" || report.buyerEmail !== email) {
      continue;
    }

    const expiresAt = report.expiresAt ? Date.parse(report.expiresAt) : null;
    if (expiresAt && Date.now() > expiresAt) {
      continue;
    }

    activeReportCount += 1;
    await logAudit(orderId, AUDIT_EVENTS.REPORT_RECOVERED, { email, channel: "email_verification" });
  }

  const emailConfigured = isEmailConfigured();
  if (activeReportCount > 0 && emailConfigured) {
    try {
      const { token } = await createMagicLinkRecord(email);
      const magicUrl = `${getSiteUrl()}/login.html?token=${encodeURIComponent(token)}&redirect=${encodeURIComponent("/dashboard.html")}`;
      const emailResult = await sendMagicLinkEmail(email, magicUrl);
      if (!emailResult.sent) {
        return sendJson(res, 200, {
          message:
            "We found reports for this email, but the recovery email could not be sent. Use the download buttons on your payment success page, or contact support@aigovernancehub.ai with your checkout email.",
          emailConfigured: false,
          emailDeliveryAvailable: false,
          requiresEmailVerification: true,
          reportsFound: true,
        });
      }
    } catch {
      return sendJson(res, 200, {
        message:
          "We found reports for this email, but the recovery email could not be sent. Use the download buttons on your payment success page, or contact support@aigovernancehub.ai with your checkout email.",
        emailConfigured: false,
        emailDeliveryAvailable: false,
        requiresEmailVerification: true,
        reportsFound: true,
      });
    }
  }

  await trackEvent("recovery_used", req, { correlationId, reportCount: activeReportCount });

  let message =
    "If purchased reports exist for this email, a secure sign-in link has been sent. Check your inbox and spam folder.";
  if (!emailConfigured) {
    message =
      activeReportCount > 0
        ? "We found reports for this email, but email delivery is not configured. Use the download buttons on your payment success page, or contact support@aigovernancehub.ai with your checkout email."
        : "If purchased reports exist for this email, recovery email is temporarily unavailable. Contact support@aigovernancehub.ai with your checkout email.";
  }

  return sendJson(res, 200, {
    message,
    emailConfigured,
    emailDeliveryAvailable: emailConfigured,
    requiresEmailVerification: true,
    reportsFound: activeReportCount > 0,
  });
}

export default async function handler(req, res) {
  const correlationId = getCorrelationId(req);
  attachCorrelation(res, correlationId);
  applySecurityHeaders(res);

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendError(res, 405, "Method not allowed.");
  }

  const kind = getKind(req);
  if (kind === "recover") {
    return handleRecoverReports(req, res, correlationId);
  }
  return handleMagicLink(req, res, correlationId);
}
